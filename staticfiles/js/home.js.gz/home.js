// console.log('sdfsdf')
// var likeEls = $('.like-bottom')

// console.log(likeEls)

// likeEls.on('click', function(event){
//     event.preventDefault();
    
// })

// for (var i = 0; i < likeEls.length; i++){
//     likeEls[i].addEventListener('click', function(e){
//         e.preventDefault()
//         if (this.style.color === 'red'){
//             this.style.color = 'black'
//         } else {
//             this.style.color = 'red'
//         }
//     })
// }
